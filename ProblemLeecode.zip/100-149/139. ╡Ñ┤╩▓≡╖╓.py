from typing import List


class Solution:
    def wordBreak(self, s: str, wordDict: List[str]) -> bool:


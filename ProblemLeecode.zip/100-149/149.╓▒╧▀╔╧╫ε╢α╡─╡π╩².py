'''
题解描述很sb。斜率表述不是问题，问题是不清楚它字典的内容。没有一点是说明白的。
'''
from typing import List


class Solution:
    def maxPoints(self, points: List[List[int]]) -> int:
        pass

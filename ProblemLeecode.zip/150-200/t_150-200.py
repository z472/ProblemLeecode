x = 0xff
print(x, bin(x))
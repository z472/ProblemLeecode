import math
print(math.log(10**4, 2))
for i in []:
    print('a')
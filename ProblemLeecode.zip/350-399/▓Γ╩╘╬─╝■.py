from collections import deque,defaultdict,Counter
import heapq
x = set()
print(2**31 / 10**8)
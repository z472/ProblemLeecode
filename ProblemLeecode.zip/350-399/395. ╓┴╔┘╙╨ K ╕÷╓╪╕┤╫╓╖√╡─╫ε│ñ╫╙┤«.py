# ???这题题解长到看吐。我为啥要挑战这种boss。
class Solution:
    def longestSubstring(self, s: str, k: int) -> int:
        pass
x = "9,#,#"
t = x.split(',')
print(t)

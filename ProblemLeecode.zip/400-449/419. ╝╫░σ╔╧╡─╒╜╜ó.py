from typing import List
class Solution:
    def countBattleships(self, board: List[List[str]]) -> int:
        '''
        py大佬 powcai之前看过很多他的题解。
        这次他的题解让我明白了题目的意思，居然是找图中的连通块个数。真的看不懂题目。理解能力~~~
        '''
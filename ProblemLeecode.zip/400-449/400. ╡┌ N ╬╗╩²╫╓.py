'''
我秒出一个蛮力的思路，然后看了两个靠前的题解，都和我一样。
也有个较快的方法，就是预先算出x位数的范围。然后就是减少很多算的时间。
https://leetcode-cn.com/problems/nth-digit/solution/lai-kan-kan-fen-xi-ni-hui-jue-de-zhe-dao-w6ze/
这题解下面有个路人说的代码。
'''
class Solution:
    def findNthDigit(self, n: int) -> int:
        pass
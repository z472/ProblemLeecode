def ret(s)->int:
    return max(s)
max = 1
print(ret(123))